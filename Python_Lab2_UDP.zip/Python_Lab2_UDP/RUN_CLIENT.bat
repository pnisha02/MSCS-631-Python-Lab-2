@echo off
cd /d "%~dp0"
py UDPPingerClient.py
pause
