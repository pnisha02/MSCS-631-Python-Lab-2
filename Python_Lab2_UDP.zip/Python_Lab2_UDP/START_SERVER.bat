@echo off
cd /d "%~dp0"
py UDPPingerServer.py
pause
