"""Send ten UDP pings with a one-second timeout and report statistics."""
import socket
import sys
import time

SERVER_HOST = sys.argv[1] if len(sys.argv) > 1 else "127.0.0.1"
SERVER_PORT = 12000
PING_COUNT = 10


def main():
    address = (socket.gethostbyname(SERVER_HOST), SERVER_PORT)
    rtts = []
    with socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as sock:
        print(f"UDP Pinger: {address[0]}:{address[1]}")
        print("Sending 10 pings; timeout = 1 second\n")
        for sequence in range(1, PING_COUNT + 1):
            message = f"Ping {sequence} {time.time():.6f}"
            expected = message.upper().encode("ascii")
            start = time.perf_counter()
            deadline = start + 1.0
            sock.sendto(message.encode("ascii"), address)
            try:
                while True:
                    remaining = deadline - time.perf_counter()
                    if remaining <= 0:
                        raise socket.timeout
                    sock.settimeout(remaining)
                    response, sender = sock.recvfrom(1024)
                    # Ignore unrelated or late replies without extending the deadline.
                    if sender != address or response != expected:
                        continue
                    rtt = time.perf_counter() - start
                    rtts.append(rtt)
                    print(f"Reply from {sender[0]}: {response.decode('ascii')}")
                    print(f"RTT = {rtt:.6f} seconds\n")
                    break
            except socket.timeout:
                print(f"Ping {sequence}: Request timed out\n")
        received = len(rtts)
        print("--- UDP Ping Statistics ---")
        print(f"Sent: {PING_COUNT}, Received: {received}, Lost: {PING_COUNT-received}")
        print(f"Packet loss: {(PING_COUNT-received)/PING_COUNT*100:.1f}%")
        if rtts:
            print(f"Minimum RTT: {min(rtts):.6f} seconds")
            print(f"Maximum RTT: {max(rtts):.6f} seconds")
            print(f"Average RTT: {sum(rtts)/received:.6f} seconds")
        else:
            print("No replies received; RTT statistics unavailable.")


if __name__ == "__main__":
    try:
        main()
    except OSError as error:
        print(f"Network error: {error}")
        print("Check the server, address, port, and firewall settings.")
        sys.exit(1)
